"""
AI FACE RECOGNITION ATTENDANCE SYSTEM
YOLO + SAHI + ArcFace + MySQL

Pipeline
--------
Webcam / CCTV / Video / RTSP
        ↓
Adaptive low-light enhancement
        ↓
Controlled resolution / small-face upscaling
        ↓
YOLO face detection
        ↓
SAHI sliced detection when difficult/small faces are detected
        ↓
Detection fusion + NMS
        ↓
Face quality + optional landmark alignment
        ↓
ArcFace embedding
        ↓
MySQL embedding gallery
        ↓
Cosine distance + best/second-best margin
        ↓
Face tracking
        ↓
Temporal confirmation
        ↓
Attendance

IMPORTANT
---------
- MySQL Server is the database. MySQL Workbench is the GUI used to inspect it.
- Raw embeddings are stored in face_embeddings.embedding_vector as BLOB.
- The frontend API shape is kept compatible with the existing project where practical.
- DeepFace is NOT used as the detector. It is used only for ArcFace embeddings.
"""

from __future__ import annotations

import base64
import math
import os
import threading
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import cv2
import numpy as np
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

try:
    import mysql.connector
    from mysql.connector import Error as MySQLError
except Exception:
    mysql = None
    MySQLError = Exception

try:
    from deepface import DeepFace
    DEEPFACE_AVAILABLE = True
    DEEPFACE_IMPORT_ERROR = ""
except Exception as exc:
    DeepFace = None
    DEEPFACE_AVAILABLE = False
    DEEPFACE_IMPORT_ERROR = str(exc)

try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
    YOLO_IMPORT_ERROR = ""
except Exception as exc:
    YOLO = None
    YOLO_AVAILABLE = False
    YOLO_IMPORT_ERROR = str(exc)

try:
    from sahi import AutoDetectionModel
    from sahi.predict import get_sliced_prediction
    SAHI_AVAILABLE = True
    SAHI_IMPORT_ERROR = ""
except Exception as exc:
    AutoDetectionModel = None
    get_sliced_prediction = None
    SAHI_AVAILABLE = False
    SAHI_IMPORT_ERROR = str(exc)


# ============================================================
# PATHS
# ============================================================

BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent

DATA_DIR = PROJECT_ROOT / "data"
MODEL_DIR = PROJECT_ROOT / "models"
RECORDINGS_DIR = PROJECT_ROOT / "recordings" / "saved"

for directory in (DATA_DIR, MODEL_DIR, RECORDINGS_DIR):
    directory.mkdir(parents=True, exist_ok=True)


# ============================================================
# ENVIRONMENT / CONFIGURATION
# ============================================================

# Load .env before reading configuration values.
ENV_FILES = [
    BACKEND_DIR / ".env",
    PROJECT_ROOT / ".env",
]

for _env_file in ENV_FILES:
    if _env_file.is_file():
        load_dotenv(_env_file, override=False)

def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() not in {"0", "false", "no", "off"}


MYSQL_HOST = os.getenv("MYSQL_HOST", "127.0.0.1")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "ai_attendance")

# YOLO face model path.
# Relative paths are resolved from the project root (the folder that
# contains main.py's backend folder), so:
#   sih/models/yolov8n-face.pt
# is found correctly even when the server is started from another folder.
_raw_yolo_model_path = os.getenv(
    "YOLO_FACE_MODEL",
    str(MODEL_DIR / "yolov8n-face.pt"),
)

_yolo_model_path = Path(_raw_yolo_model_path)

if not _yolo_model_path.is_absolute():
    _project_candidate = PROJECT_ROOT / _yolo_model_path
    _backend_candidate = BACKEND_DIR / _yolo_model_path

    if _project_candidate.is_file():
        _yolo_model_path = _project_candidate
    elif _backend_candidate.is_file():
        _yolo_model_path = _backend_candidate
    else:
        # Keep the project-root interpretation in the error message.
        _yolo_model_path = _project_candidate

YOLO_MODEL_PATH = str(_yolo_model_path.resolve())
YOLO_INPUT_SIZE = int(os.getenv("YOLO_INPUT_SIZE", "1280"))
YOLO_CONFIDENCE = float(os.getenv("YOLO_CONFIDENCE", "0.25"))
YOLO_IOU = float(os.getenv("YOLO_IOU", "0.45"))
YOLO_MAX_DETECTIONS = int(os.getenv("YOLO_MAX_DETECTIONS", "100"))
YOLO_DEVICE = os.getenv("YOLO_DEVICE", "")

SAHI_ENABLED = env_bool("SAHI_ENABLED", True)
SAHI_SLICE_HEIGHT = int(os.getenv("SAHI_SLICE_HEIGHT", "512"))
SAHI_SLICE_WIDTH = int(os.getenv("SAHI_SLICE_WIDTH", "512"))
SAHI_OVERLAP = float(os.getenv("SAHI_OVERLAP", "0.25"))
SAHI_CONFIDENCE = float(os.getenv("SAHI_CONFIDENCE", "0.20"))
SAHI_MERGE_IOU = float(os.getenv("SAHI_MERGE_IOU", "0.50"))

LOW_LIGHT_ENABLED = env_bool("LOW_LIGHT_ENABLED", True)
LOW_LIGHT_MEAN_THRESHOLD = float(
    os.getenv("LOW_LIGHT_MEAN_THRESHOLD", "82")
)
LOW_LIGHT_DARK_PIXEL_RATIO = float(
    os.getenv("LOW_LIGHT_DARK_PIXEL_RATIO", "0.35")
)
LOW_LIGHT_GAMMA = float(os.getenv("LOW_LIGHT_GAMMA", "0.72"))
CLAHE_CLIP = float(os.getenv("CLAHE_CLIP", "2.2"))
CLAHE_GRID = int(os.getenv("CLAHE_GRID", "8"))

UPSCALE_ENABLED = env_bool("UPSCALE_ENABLED", True)
UPSCALE_FACTOR = float(os.getenv("UPSCALE_FACTOR", "1.50"))
UPSCALE_MAX_FACTOR = float(os.getenv("UPSCALE_MAX_FACTOR", "2.0"))
UPSCALE_TRIGGER_SHORT_SIDE = int(
    os.getenv("UPSCALE_TRIGGER_SHORT_SIDE", "720")
)
SMALL_FACE_RATIO = float(os.getenv("SMALL_FACE_RATIO", "0.065"))

ARCFACE_MODEL_NAME = os.getenv("ARCFACE_MODEL_NAME", "ArcFace")
ARCFACE_DISTANCE_METRIC = "cosine"
EMBEDDING_DIMENSION = 512

DEFAULT_FACE_THRESHOLD = float(
    os.getenv(
        "DEFAULT_FACE_THRESHOLD",
        os.getenv("FACE_THRESHOLD", "0.48"),
    )
)
VIDEO_THRESHOLD = float(os.getenv("VIDEO_THRESHOLD", "0.52"))
MIN_FACE_QUALITY = float(os.getenv("MIN_FACE_QUALITY", "38"))
MARGIN_THRESHOLD = float(os.getenv("MARGIN_THRESHOLD", "0.035"))

TEMPORAL_REQUIRED = int(
    os.getenv(
        "TEMPORAL_REQUIRED",
        os.getenv("CONFIRM_OBSERVATIONS", "3"),
    )
)
TEMPORAL_WINDOW_SECONDS = float(
    os.getenv("TEMPORAL_WINDOW_SECONDS", "2.5")
)
TRACK_MAX_AGE = float(os.getenv("TRACK_MAX_AGE", "5.0"))
RECOGNITION_INTERVAL = float(os.getenv("RECOGNITION_INTERVAL", "0.15"))

MAX_FRAME_WIDTH = int(os.getenv("MAX_FRAME_WIDTH", "1920"))
INFERENCE_LOCK = threading.Lock()
DB_LOCK = threading.RLock()
MODEL_LOCK = threading.RLock()
RTSP_LOCK = threading.RLock()

YOLO_MODEL: Any = None
SAHI_MODEL: Any = None

YOLO_READY = False
YOLO_ERROR = ""
SAHI_READY = False
SAHI_ERROR = ""

ARCFACE_READY = False
ARCFACE_ERROR = ""

STUDENT_CACHE: dict[tuple[str, str], tuple[float, list[dict[str, Any]]]] = {}
CACHE_TTL = 10.0

SESSION_STATE: dict[int, dict[str, Any]] = {}
RTSP_STREAMS: dict[str, dict[str, Any]] = {}


def mysql_password_loaded() -> bool:
    return bool(MYSQL_PASSWORD)


# ============================================================
# DATABASE
# ============================================================

def mysql_server_connection():
    if mysql is None:
        raise RuntimeError(
            "mysql-connector-python is not installed."
        )
    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
    )


def db():
    if mysql is None:
        raise RuntimeError(
            "mysql-connector-python is not installed."
        )
    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        autocommit=False,
    )


def initialize_database():
    """
    Creates the MySQL database and tables if they do not exist.
    Existing MySQL data is not deleted.
    """
    conn = mysql_server_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            f"CREATE DATABASE IF NOT EXISTS `{MYSQL_DATABASE}` "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
        conn.commit()
    finally:
        conn.close()

    conn = db()
    try:
        cur = conn.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                student_id VARCHAR(100) NOT NULL,
                name VARCHAR(160) NOT NULL,
                class_name VARCHAR(120) NOT NULL,
                division VARCHAR(40) NOT NULL,
                email VARCHAR(255) DEFAULT '',
                phone VARCHAR(50) DEFAULT '',
                photo_data LONGTEXT,
                created_at DATETIME(6) NOT NULL,
                updated_at DATETIME(6) NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_students_student_id (student_id),
                KEY idx_students_class_div (
                    class_name, division
                )
            ) ENGINE=InnoDB
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS face_embeddings (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                student_db_id BIGINT UNSIGNED NOT NULL,
                embedding_vector BLOB NOT NULL,
                model_name VARCHAR(80) NOT NULL,
                embedding_dimension INT NOT NULL,
                created_at DATETIME(6) NOT NULL,
                PRIMARY KEY (id),
                KEY idx_embeddings_student (student_db_id),
                CONSTRAINT fk_embeddings_student
                    FOREIGN KEY (student_db_id)
                    REFERENCES students(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS attendance_sessions (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                session_key VARCHAR(64) NOT NULL,
                class_name VARCHAR(120) NOT NULL,
                division VARCHAR(40) NOT NULL,
                subject VARCHAR(160) NOT NULL,
                room VARCHAR(120) NOT NULL,
                source_type VARCHAR(40) NOT NULL,
                threshold DOUBLE NOT NULL,
                started_at DATETIME(6) NOT NULL,
                ended_at DATETIME(6) NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_session_key (session_key),
                KEY idx_sessions_class_div (
                    class_name, division
                )
            ) ENGINE=InnoDB
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                session_id BIGINT UNSIGNED NOT NULL,
                student_db_id BIGINT UNSIGNED NOT NULL,
                marked_at DATETIME(6) NOT NULL,
                distance DOUBLE NOT NULL,
                confidence DOUBLE NOT NULL,
                method VARCHAR(80) NOT NULL,
                video_timestamp DOUBLE NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_session_student (
                    session_id, student_db_id
                ),
                KEY idx_attendance_date (marked_at),
                CONSTRAINT fk_attendance_session
                    FOREIGN KEY (session_id)
                    REFERENCES attendance_sessions(id)
                    ON DELETE CASCADE,
                CONSTRAINT fk_attendance_student
                    FOREIGN KEY (student_db_id)
                    REFERENCES students(id)
                    ON DELETE CASCADE
            ) ENGINE=InnoDB
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS activities (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                activity_type VARCHAR(100) NOT NULL,
                message VARCHAR(500) NOT NULL,
                created_at DATETIME(6) NOT NULL,
                PRIMARY KEY (id),
                KEY idx_activity_created (created_at)
            ) ENGINE=InnoDB
        """)

        conn.commit()
    finally:
        conn.close()


def now_dt() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def add_activity(activity_type: str, message: str):
    try:
        with DB_LOCK:
            conn = db()
            try:
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO activities
                    (activity_type, message, created_at)
                    VALUES (%s, %s, %s)
                    """,
                    (activity_type, message, now_dt()),
                )
                conn.commit()
            finally:
                conn.close()
    except Exception:
        pass


# ============================================================
# EMBEDDING STORAGE
# ============================================================

def normalize_embedding(vector: Any) -> np.ndarray:
    arr = np.asarray(vector, dtype=np.float32).reshape(-1)

    if arr.size != EMBEDDING_DIMENSION:
        raise ValueError(
            f"Expected {EMBEDDING_DIMENSION}-D embedding, "
            f"got {arr.size}-D."
        )

    norm = float(np.linalg.norm(arr))
    if norm <= 1e-12:
        raise ValueError("Embedding norm is zero.")

    return (arr / norm).astype(np.float32)


def embedding_to_blob(embedding: np.ndarray) -> bytes:
    return normalize_embedding(embedding).tobytes()


def blob_to_embedding(blob: bytes) -> np.ndarray:
    return normalize_embedding(
        np.frombuffer(blob, dtype=np.float32)
    )


def save_embedding(
    student_db_id: int,
    embedding: np.ndarray,
):
    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO face_embeddings
                (
                    student_db_id,
                    embedding_vector,
                    model_name,
                    embedding_dimension,
                    created_at
                )
                VALUES (%s, %s, %s, %s, %s)
                """,
                (
                    student_db_id,
                    embedding_to_blob(embedding),
                    ARCFACE_MODEL_NAME,
                    EMBEDDING_DIMENSION,
                    now_dt(),
                ),
            )
            conn.commit()
        finally:
            conn.close()


def replace_student_embeddings(
    student_db_id: int,
    embeddings: list[np.ndarray],
):
    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM face_embeddings "
                "WHERE student_db_id=%s",
                (student_db_id,),
            )

            for embedding in embeddings:
                cur.execute(
                    """
                    INSERT INTO face_embeddings
                    (
                        student_db_id,
                        embedding_vector,
                        model_name,
                        embedding_dimension,
                        created_at
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (
                        student_db_id,
                        embedding_to_blob(embedding),
                        ARCFACE_MODEL_NAME,
                        EMBEDDING_DIMENSION,
                        now_dt(),
                    ),
                )
            conn.commit()
        finally:
            conn.close()


def load_students(
    class_name: str = "",
    division: str = "",
) -> list[dict[str, Any]]:
    key = (class_name, division)
    cached = STUDENT_CACHE.get(key)

    if cached and time.time() - cached[0] < CACHE_TTL:
        return cached[1]

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)

            if class_name and division:
                cur.execute(
                    """
                    SELECT
                        s.id,
                        s.student_id,
                        s.name,
                        s.class_name,
                        s.division,
                        s.email,
                        s.phone,
                        s.photo_data,
                        e.id AS embedding_id,
                        e.embedding_vector
                    FROM students s
                    LEFT JOIN face_embeddings e
                        ON e.student_db_id = s.id
                    WHERE s.class_name=%s
                      AND s.division=%s
                    ORDER BY s.id DESC, e.id ASC
                    """,
                    (class_name, division),
                )
            else:
                cur.execute(
                    """
                    SELECT
                        s.id,
                        s.student_id,
                        s.name,
                        s.class_name,
                        s.division,
                        s.email,
                        s.phone,
                        s.photo_data,
                        e.id AS embedding_id,
                        e.embedding_vector
                    FROM students s
                    LEFT JOIN face_embeddings e
                        ON e.student_db_id = s.id
                    ORDER BY s.id DESC, e.id ASC
                    """
                )

            rows = cur.fetchall()
        finally:
            conn.close()

    grouped: dict[int, dict[str, Any]] = {}

    for row in rows:
        sid = int(row["id"])

        if sid not in grouped:
            grouped[sid] = {
                "id": sid,
                "student_id": row["student_id"],
                "name": row["name"],
                "class_name": row["class_name"],
                "division": row["division"],
                "email": row["email"] or "",
                "phone": row["phone"] or "",
                "photo_data": row["photo_data"] or "",
                "embeddings": [],
            }

        if row["embedding_vector"] is not None:
            try:
                grouped[sid]["embeddings"].append(
                    blob_to_embedding(row["embedding_vector"])
                )
            except Exception:
                pass

    result = list(grouped.values())
    STUDENT_CACHE[key] = (time.time(), result)
    return result


def clear_student_cache():
    STUDENT_CACHE.clear()


# ============================================================
# IMAGE / LOW-LIGHT / RESOLUTION
# ============================================================

def decode_image(data: bytes) -> np.ndarray:
    array = np.frombuffer(data, dtype=np.uint8)
    frame = cv2.imdecode(array, cv2.IMREAD_COLOR)

    if frame is None:
        raise HTTPException(400, "Invalid image.")

    return frame


def resize_for_ai(frame: np.ndarray) -> np.ndarray:
    """
    Do not blindly downscale every frame.

    Large frames are capped at MAX_FRAME_WIDTH. Small frames are
    retained so that the adaptive upscaling stage can help YOLO.
    """
    h, w = frame.shape[:2]

    if w > MAX_FRAME_WIDTH:
        scale = MAX_FRAME_WIDTH / float(w)
        return cv2.resize(
            frame,
            (int(w * scale), int(h * scale)),
            interpolation=cv2.INTER_AREA,
        )

    return frame


def estimate_lighting(frame: np.ndarray) -> dict[str, float | bool]:
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    mean_brightness = float(np.mean(gray))
    dark_ratio = float(np.mean(gray < 55))
    very_dark_ratio = float(np.mean(gray < 35))

    low_light = (
        mean_brightness < LOW_LIGHT_MEAN_THRESHOLD
        or dark_ratio > LOW_LIGHT_DARK_PIXEL_RATIO
    )

    return {
        "mean_brightness": mean_brightness,
        "dark_ratio": dark_ratio,
        "very_dark_ratio": very_dark_ratio,
        "low_light": bool(low_light),
    }


def gamma_correct(frame: np.ndarray, gamma: float) -> np.ndarray:
    gamma = max(0.45, min(1.4, float(gamma)))
    inv = 1.0 / gamma
    table = np.array(
        [((i / 255.0) ** inv) * 255 for i in range(256)],
        dtype=np.uint8,
    )
    return cv2.LUT(frame, table)


def enhance_low_light(
    frame: np.ndarray,
) -> tuple[np.ndarray, dict[str, Any]]:
    meta = estimate_lighting(frame)

    if not LOW_LIGHT_ENABLED or not meta["low_light"]:
        return frame, {
            **meta,
            "enhanced": False,
        }

    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)

    clahe = cv2.createCLAHE(
        clipLimit=CLAHE_CLIP,
        tileGridSize=(CLAHE_GRID, CLAHE_GRID),
    )
    l_channel = clahe.apply(l_channel)

    enhanced = cv2.cvtColor(
        cv2.merge((l_channel, a_channel, b_channel)),
        cv2.COLOR_LAB2BGR,
    )

    enhanced = gamma_correct(enhanced, LOW_LIGHT_GAMMA)

    # Very mild denoising so CLAHE does not amplify sensor noise.
    enhanced = cv2.GaussianBlur(enhanced, (3, 3), 0)

    return enhanced, {
        **meta,
        "enhanced": True,
    }


def prepare_detection_frame(
    original: np.ndarray,
) -> tuple[np.ndarray, float, dict[str, Any]]:
    """
    Returns:
        prepared frame,
        scale from prepared coordinates to original coordinates,
        preprocessing metadata.

    The frame is enhanced only when it is actually dark.
    Small/low-resolution input is upscaled before detection.
    """
    frame = resize_for_ai(original)
    frame, light_meta = enhance_low_light(frame)

    h, w = frame.shape[:2]
    short_side = min(h, w)

    scale = 1.0

    if UPSCALE_ENABLED and short_side < UPSCALE_TRIGGER_SHORT_SIDE:
        scale = min(
            UPSCALE_FACTOR,
            UPSCALE_MAX_FACTOR,
            1600.0 / max(short_side, 1),
        )

    if scale > 1.01:
        frame = cv2.resize(
            frame,
            (int(w * scale), int(h * scale)),
            interpolation=cv2.INTER_CUBIC,
        )

    return frame, scale, {
        "low_light": light_meta,
        "upscale_factor": scale,
        "prepared_width": int(frame.shape[1]),
        "prepared_height": int(frame.shape[0]),
    }


# ============================================================
# MODEL LOADING
# ============================================================

def load_yolo_model():
    global YOLO_MODEL, YOLO_READY, YOLO_ERROR

    if not YOLO_AVAILABLE:
        YOLO_READY = False
        YOLO_ERROR = YOLO_IMPORT_ERROR
        return

    if not Path(YOLO_MODEL_PATH).is_file():
        YOLO_READY = False
        YOLO_ERROR = (
            f"YOLO model not found: {YOLO_MODEL_PATH}. "
            "Place the face model at that path."
        )
        return

    try:
        with MODEL_LOCK:
            YOLO_MODEL = YOLO(YOLO_MODEL_PATH)

        YOLO_READY = True
        YOLO_ERROR = ""
    except Exception as exc:
        YOLO_READY = False
        YOLO_ERROR = str(exc)


def load_sahi_model():
    global SAHI_MODEL, SAHI_READY, SAHI_ERROR

    if not SAHI_ENABLED:
        SAHI_READY = False
        SAHI_ERROR = "SAHI disabled by configuration."
        return

    if not SAHI_AVAILABLE:
        SAHI_READY = False
        SAHI_ERROR = SAHI_IMPORT_ERROR
        return

    if not YOLO_READY:
        SAHI_READY = False
        SAHI_ERROR = "YOLO model must load before SAHI."
        return

    try:
        with MODEL_LOCK:
            SAHI_MODEL = AutoDetectionModel.from_pretrained(
                model_type="ultralytics",
                model_path=YOLO_MODEL_PATH,
                confidence_threshold=SAHI_CONFIDENCE,
                device=YOLO_DEVICE or None,
            )

        SAHI_READY = True
        SAHI_ERROR = ""
    except Exception as exc:
        SAHI_READY = False
        SAHI_ERROR = str(exc)


def warmup_arcface():
    global ARCFACE_READY, ARCFACE_ERROR

    if not DEEPFACE_AVAILABLE:
        ARCFACE_READY = False
        ARCFACE_ERROR = DEEPFACE_IMPORT_ERROR
        return

    try:
        dummy = np.zeros((224, 224, 3), dtype=np.uint8)

        with INFERENCE_LOCK:
            result = DeepFace.represent(
                img_path=dummy,
                model_name=ARCFACE_MODEL_NAME,
                detector_backend="skip",
                enforce_detection=False,
                normalization="base",
            )

        if not result:
            raise RuntimeError("ArcFace warmup returned no embedding.")

        embedding = normalize_embedding(result[0]["embedding"])

        if embedding.size != EMBEDDING_DIMENSION:
            raise RuntimeError(
                f"{ARCFACE_MODEL_NAME} returned "
                f"{embedding.size} dimensions."
            )

        ARCFACE_READY = True
        ARCFACE_ERROR = ""
    except Exception as exc:
        ARCFACE_READY = False
        ARCFACE_ERROR = str(exc)


def require_ai():
    if not ARCFACE_READY:
        raise HTTPException(
            503,
            f"ArcFace is not ready: {ARCFACE_ERROR}",
        )

    if not YOLO_READY:
        raise HTTPException(
            503,
            f"YOLO is not ready: {YOLO_ERROR}",
        )


# ============================================================
# DETECTION
# ============================================================

def clamp_box(
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    width: int,
    height: int,
) -> tuple[int, int, int, int]:
    x1 = max(0, min(width - 1, int(round(x1))))
    y1 = max(0, min(height - 1, int(round(y1))))
    x2 = max(x1 + 1, min(width, int(round(x2))))
    y2 = max(y1 + 1, min(height, int(round(y2))))
    return x1, y1, x2, y2


def box_intersection_over_smaller(
    a: dict[str, Any],
    b: dict[str, Any],
) -> float:
    """Return intersection divided by the area of the smaller box.

    This catches nested detections that ordinary IoU can miss. A common
    false-positive pattern is a small box drawn inside the correct face box;
    its IoU with the larger box can be below the normal NMS threshold even
    though 100% of the small detection is contained by the larger one.
    """
    ax1, ay1 = float(a["x"]), float(a["y"])
    ax2 = ax1 + float(a["w"])
    ay2 = ay1 + float(a["h"])

    bx1, by1 = float(b["x"]), float(b["y"])
    bx2 = bx1 + float(b["w"])
    by2 = by1 + float(b["h"])

    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)

    intersection = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    if intersection <= 0.0:
        return 0.0

    area_a = max(0.0, float(a["w"])) * max(0.0, float(a["h"]))
    area_b = max(0.0, float(b["w"])) * max(0.0, float(b["h"]))
    smaller = min(area_a, area_b)

    return intersection / smaller if smaller > 0.0 else 0.0


def suppress_nested_face_detections(
    faces: list[dict[str, Any]],
    containment_threshold: float = 0.70,
    iou_threshold: float = 0.50,
) -> list[dict[str, Any]]:
    """Keep one detection per physical face.

    Uses confidence-first greedy suppression with both IoU and
    intersection-over-smaller-area. The latter specifically removes
    small/nested false boxes such as the orange box visible inside the
    correct green face box.
    """
    ordered = sorted(
        faces,
        key=lambda face: (
            float(face.get("confidence", 0.0)),
            float(face.get("w", 0.0)) * float(face.get("h", 0.0)),
        ),
        reverse=True,
    )

    kept: list[dict[str, Any]] = []

    for candidate in ordered:
        duplicate = False

        for existing in kept:
            iou = box_iou(candidate, existing)
            containment = box_intersection_over_smaller(
                candidate,
                existing,
            )

            if (
                iou >= iou_threshold
                or containment >= containment_threshold
            ):
                duplicate = True
                break

        if not duplicate:
            kept.append(dict(candidate))

    return kept


def box_iou(a: dict[str, Any], b: dict[str, Any]) -> float:
    ax1, ay1 = a["x"], a["y"]
    ax2, ay2 = ax1 + a["w"], ay1 + a["h"]

    bx1, by1 = b["x"], b["y"]
    bx2, by2 = bx1 + b["w"], by1 + b["h"]

    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)

    iw = max(0, ix2 - ix1)
    ih = max(0, iy2 - iy1)
    intersection = iw * ih

    union = (
        max(0, ax2 - ax1) * max(0, ay2 - ay1)
        + max(0, bx2 - bx1) * max(0, by2 - by1)
        - intersection
    )

    return intersection / union if union > 0 else 0.0


def parse_yolo_results(
    results: Any,
    scale_back: float = 1.0,
) -> list[dict[str, Any]]:
    detections: list[dict[str, Any]] = []

    if not results:
        return detections

    result = results[0]

    if result.boxes is None:
        return detections

    boxes = result.boxes
    keypoints = getattr(result, "keypoints", None)

    frame_h, frame_w = result.orig_shape[:2]

    for index in range(len(boxes)):
        xyxy = boxes.xyxy[index].detach().cpu().numpy()
        confidence = float(
            boxes.conf[index].detach().cpu().item()
        )

        x1, y1, x2, y2 = xyxy.tolist()

        x1 /= scale_back
        y1 /= scale_back
        x2 /= scale_back
        y2 /= scale_back

        x1, y1, x2, y2 = clamp_box(
            x1,
            y1,
            x2,
            y2,
            int(frame_w / scale_back),
            int(frame_h / scale_back),
        )

        item: dict[str, Any] = {
            "x": x1,
            "y": y1,
            "w": x2 - x1,
            "h": y2 - y1,
            "confidence": confidence,
            "source": "yolo",
        }

        # Some YOLO face models expose keypoints. Keep them when present.
        if keypoints is not None:
            try:
                pts = (
                    keypoints.xy[index]
                    .detach()
                    .cpu()
                    .numpy()
                )
                item["landmarks"] = [
                    [
                        float(point[0] / scale_back),
                        float(point[1] / scale_back),
                    ]
                    for point in pts
                ]
            except Exception:
                pass

        detections.append(item)

    return detections


def run_yolo_detection(
    prepared: np.ndarray,
    scale_back: float,
) -> list[dict[str, Any]]:
    if not YOLO_READY or YOLO_MODEL is None:
        return []

    kwargs: dict[str, Any] = {
        "source": prepared,
        "conf": YOLO_CONFIDENCE,
        "iou": YOLO_IOU,
        "imgsz": YOLO_INPUT_SIZE,
        "max_det": YOLO_MAX_DETECTIONS,
        "verbose": False,
    }

    if YOLO_DEVICE:
        kwargs["device"] = YOLO_DEVICE

    try:
        with MODEL_LOCK:
            results = YOLO_MODEL.predict(**kwargs)

        return parse_yolo_results(
            results,
            scale_back=scale_back,
        )
    except Exception:
        return []


def run_sahi_detection(
    prepared: np.ndarray,
    scale_back: float,
) -> list[dict[str, Any]]:
    if not SAHI_READY or SAHI_MODEL is None:
        return []

    try:
        with MODEL_LOCK:
            result = get_sliced_prediction(
                prepared,
                SAHI_MODEL,
                slice_height=SAHI_SLICE_HEIGHT,
                slice_width=SAHI_SLICE_WIDTH,
                overlap_height_ratio=SAHI_OVERLAP,
                overlap_width_ratio=SAHI_OVERLAP,
                perform_standard_pred=False,
                postprocess_type="GREEDYNMM",
                postprocess_match_metric="IOU",
                postprocess_match_threshold=SAHI_MERGE_IOU,
                verbose=0,
            )

        detections: list[dict[str, Any]] = []

        for obj in result.object_prediction_list:
            bbox = obj.bbox
            x1 = float(bbox.minx) / scale_back
            y1 = float(bbox.miny) / scale_back
            x2 = float(bbox.maxx) / scale_back
            y2 = float(bbox.maxy) / scale_back

            x1, y1, x2, y2 = clamp_box(
                x1,
                y1,
                x2,
                y2,
                int(prepared.shape[1] / scale_back),
                int(prepared.shape[0] / scale_back),
            )

            detections.append(
                {
                    "x": x1,
                    "y": y1,
                    "w": x2 - x1,
                    "h": y2 - y1,
                    "confidence": float(
                        obj.score.value
                    ),
                    "source": "sahi",
                }
            )

        return detections
    except Exception:
        return []


def merge_detections(
    yolo: list[dict[str, Any]],
    sahi: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """
    Confidence-aware fusion.

    SAHI detections are not simply appended. Overlapping boxes are merged
    so one face does not become two faces.
    """
    combined = yolo + sahi
    combined.sort(
        key=lambda x: x["confidence"],
        reverse=True,
    )

    kept: list[dict[str, Any]] = []

    for candidate in combined:
        duplicate = False

        for existing in kept:
            if box_iou(candidate, existing) >= SAHI_MERGE_IOU:
                duplicate = True

                # Keep the stronger box, but remember that SAHI contributed.
                if candidate["confidence"] > existing["confidence"]:
                    existing.update(candidate)

                if (
                    candidate["source"] == "sahi"
                    and existing.get("source") == "yolo"
                ):
                    existing["source"] = "yolo+sahi"

                break

        if not duplicate:
            kept.append(dict(candidate))

    return kept


def detect_faces(
    frame: np.ndarray,
    source_type: str = "webcam",
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """
    Main detector.

    SAHI is intentionally triggered for difficult frames:
    - no YOLO detections
    - very small detected faces
    - low-light frames
    - low-resolution input

    This makes SAHI useful without forcing the expensive sliced detector
    on every normal webcam frame.
    """
    prepared, scale_back, preprocess_meta = prepare_detection_frame(frame)

    yolo_faces = run_yolo_detection(
        prepared,
        scale_back=scale_back,
    )

    image_area = float(
        max(frame.shape[0] * frame.shape[1], 1)
    )

    small_face = False

    for face in yolo_faces:
        relative_size = math.sqrt(
            max(face["w"] * face["h"], 1.0)
            / image_area
        )
        face["relative_size"] = relative_size

        if relative_size < SMALL_FACE_RATIO:
            small_face = True

    low_light = bool(
        preprocess_meta["low_light"]["low_light"]
    )
    low_resolution = min(
        frame.shape[:2]
    ) < UPSCALE_TRIGGER_SHORT_SIDE

    difficult_source = source_type.lower() in {
        "cctv",
        "rtsp",
        "video",
    }

    use_sahi = (
        SAHI_ENABLED
        and SAHI_READY
        and (
            len(yolo_faces) == 0
            or small_face
            or low_light
            or low_resolution
            or difficult_source and small_face
        )
    )

    sahi_faces = (
        run_sahi_detection(
            prepared,
            scale_back=scale_back,
        )
        if use_sahi
        else []
    )

    faces = merge_detections(
        yolo_faces,
        sahi_faces,
    )

    # Final physical-face suppression. Ordinary IoU NMS is not sufficient
    # for nested boxes: a small false box can sit completely inside the
    # correct box while still having a modest IoU with it.
    faces = suppress_nested_face_detections(
        faces,
        containment_threshold=0.70,
        iou_threshold=0.50,
    )

    for face in faces:
        face.pop("relative_size", None)

    meta = {
        "yolo_count": len(yolo_faces),
        "sahi_count": len(sahi_faces),
        "sahi_used": use_sahi,
        "sahi_ready": SAHI_READY,
        "preprocessing": preprocess_meta,
    }

    return faces, meta


# ============================================================
# FACE CROP / ALIGNMENT / QUALITY
# ============================================================

ARC_TEMPLATE = np.array(
    [
        [38.2946, 51.6963],
        [73.5318, 51.5014],
        [56.0252, 71.7366],
        [41.5493, 92.3655],
        [70.7299, 92.2041],
    ],
    dtype=np.float32,
)


def crop_face(
    frame: np.ndarray,
    face: dict[str, Any],
    pad: float = 0.20,
    upscale: bool = True,
) -> np.ndarray:
    h, w = frame.shape[:2]

    x = int(face["x"])
    y = int(face["y"])
    bw = int(face["w"])
    bh = int(face["h"])

    px = int(bw * pad)
    py = int(bh * pad)

    x1 = max(0, x - px)
    y1 = max(0, y - py)
    x2 = min(w, x + bw + px)
    y2 = min(h, y + bh + py)

    crop = frame[y1:y2, x1:x2]

    if crop.size == 0:
        return crop

    if upscale:
        ch, cw = crop.shape[:2]
        if min(ch, cw) < 160:
            scale = min(
                3.0,
                160.0 / max(min(ch, cw), 1),
            )
            crop = cv2.resize(
                crop,
                (int(cw * scale), int(ch * scale)),
                interpolation=cv2.INTER_CUBIC,
            )

    return crop


def align_face(
    frame: np.ndarray,
    face: dict[str, Any],
) -> np.ndarray:
    """
    Uses real YOLO keypoints when the loaded face model provides them.

    If the model does not expose landmarks, a conservative padded crop is
    used rather than inventing inaccurate eye/nose coordinates.
    """
    landmarks = face.get("landmarks")

    if landmarks and len(landmarks) >= 5:
        points = np.asarray(
            landmarks[:5],
            dtype=np.float32,
        )

        if points.shape == (5, 2):
            transform, _ = cv2.estimateAffinePartial2D(
                points,
                ARC_TEMPLATE,
                method=cv2.LMEDS,
            )

            if transform is not None:
                aligned = cv2.warpAffine(
                    frame,
                    transform,
                    (112, 112),
                    flags=cv2.INTER_CUBIC,
                    borderMode=cv2.BORDER_REPLICATE,
                )
                return aligned

    crop = crop_face(
        frame,
        face,
        pad=0.25,
        upscale=True,
    )

    if crop.size == 0:
        return crop

    return cv2.resize(
        crop,
        (112, 112),
        interpolation=cv2.INTER_CUBIC,
    )


def calculate_quality(
    crop: np.ndarray,
) -> tuple[float, dict[str, float]]:
    if crop is None or crop.size == 0:
        return 0.0, {
            "sharpness": 0.0,
            "brightness": 0.0,
            "contrast": 0.0,
        }

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    sharpness = float(
        cv2.Laplacian(gray, cv2.CV_64F).var()
    )

    brightness = float(np.mean(gray))
    contrast = float(np.std(gray))

    sharp_score = min(100.0, sharpness / 3.0)

    brightness_score = max(
        0.0,
        100.0
        - abs(brightness - 128.0) * 1.35,
    )

    contrast_score = min(
        100.0,
        contrast * 2.0,
    )

    quality = (
        0.45 * sharp_score
        + 0.30 * brightness_score
        + 0.25 * contrast_score
    )

    return float(max(0.0, min(100.0, quality))), {
        "sharpness": sharpness,
        "brightness": brightness,
        "contrast": contrast,
    }


# ============================================================
# ARCFACE
# ============================================================

def embedding_from_crop(crop: np.ndarray) -> np.ndarray:
    if not ARCFACE_READY or DeepFace is None:
        raise RuntimeError(
            f"ArcFace is not ready: {ARCFACE_ERROR}"
        )

    if crop is None or crop.size == 0:
        raise ValueError("Empty face crop.")

    with INFERENCE_LOCK:
        result = DeepFace.represent(
            img_path=crop,
            model_name=ARCFACE_MODEL_NAME,
            detector_backend="skip",
            enforce_detection=False,
            normalization="base",
        )

    if not result:
        raise RuntimeError(
            "ArcFace returned no embedding."
        )

    return normalize_embedding(
        result[0]["embedding"]
    )


def build_registration_embeddings(
    aligned_face: np.ndarray,
) -> list[np.ndarray]:
    """
    Creates a small, controlled gallery from the same enrollment image.

    This is not a substitute for genuine multi-angle enrollment.
    """
    variants = [
        aligned_face,
        cv2.flip(aligned_face, 1),
    ]

    embeddings: list[np.ndarray] = []

    for variant in variants:
        try:
            embeddings.append(
                embedding_from_crop(variant)
            )
        except Exception:
            continue

    if not embeddings:
        raise RuntimeError(
            "Unable to create an ArcFace embedding."
        )

    return embeddings


def cosine_distance(
    a: np.ndarray,
    b: np.ndarray,
) -> float:
    a = normalize_embedding(a)
    b = normalize_embedding(b)
    return float(1.0 - np.dot(a, b))


def best_gallery_match(
    query_embedding: np.ndarray,
    students: list[dict[str, Any]],
) -> dict[str, Any]:
    best_student = None
    best_distance = float("inf")
    second_best = float("inf")

    for student in students:
        embeddings = student.get("embeddings", [])

        if not embeddings:
            continue

        student_best = min(
            cosine_distance(query_embedding, emb)
            for emb in embeddings
        )

        if student_best < best_distance:
            second_best = best_distance
            best_distance = student_best
            best_student = student
        elif student_best < second_best:
            second_best = student_best

    margin = (
        second_best - best_distance
        if math.isfinite(second_best)
        else 1.0
    )

    return {
        "student": best_student,
        "best_distance": best_distance,
        "second_best_distance": second_best,
        "margin": margin,
    }


# ============================================================
# TRACKING
# ============================================================

def _box_center(face: dict[str, Any]) -> tuple[float, float]:
    return (
        float(face["x"]) + float(face["w"]) / 2.0,
        float(face["y"]) + float(face["h"]) / 2.0,
    )


def _center_distance_ratio(
    a: dict[str, Any],
    b: dict[str, Any],
) -> float:
    ax, ay = _box_center(a)
    bx, by = _box_center(b)
    distance = math.hypot(ax - bx, ay - by)

    reference = max(
        1.0,
        (float(a["w"]) + float(a["h"]) +
         float(b["w"]) + float(b["h"])) / 4.0,
    )
    return distance / reference


def update_tracks(
    tracks: list[dict[str, Any]],
    faces: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """
    Robust lightweight tracker.

    The previous tracker required IoU >= 0.20. Face detector boxes can move
    or resize slightly between webcam frames, which can make IoU fall below
    that value and create a NEW track every frame. That prevents temporal
    confirmation from ever reaching 2/3 observations.

    We now match using either:
      - IoU >= 0.10, OR
      - a sufficiently small normalized center movement.

    Matching is still confidence/overlap aware and stale tracks expire.
    """
    now = time.time()

    active = [
        track
        for track in tracks
        if now - track["last"] <= TRACK_MAX_AGE
    ]

    # Build candidate matches and greedily take the strongest ones.
    candidates: list[tuple[float, int, int]] = []

    for face_index, face in enumerate(faces):
        for track_index, track in enumerate(active):
            old_box = track["box"]
            overlap = box_iou(face, old_box)
            center_ratio = _center_distance_ratio(face, old_box)

            # Allow normal detector jitter. For a webcam face, a center
            # movement below roughly half the average box dimension is still
            # overwhelmingly likely to be the same physical face.
            if overlap >= 0.10 or center_ratio <= 0.65:
                score = overlap + max(
                    0.0,
                    0.65 - center_ratio,
                ) * 0.25
                candidates.append(
                    (score, face_index, track_index)
                )

    candidates.sort(reverse=True)

    used_faces: set[int] = set()
    used_tracks: set[int] = set()

    for _score, face_index, track_index in candidates:
        if face_index in used_faces or track_index in used_tracks:
            continue

        face = faces[face_index]
        track = active[track_index]

        track["box"] = dict(face)
        track["last"] = now
        face["track_id"] = track["track_id"]

        used_faces.add(face_index)
        used_tracks.add(track_index)

    # Any unmatched detection starts a new track.
    for face_index, face in enumerate(faces):
        if face_index in used_faces:
            continue

        track_id = uuid.uuid4().hex[:8]
        active.append(
            {
                "track_id": track_id,
                "box": dict(face),
                "last": now,
            }
        )
        face["track_id"] = track_id

    return active, faces


def temporal_confirmation(
    state: dict[str, Any],
    face: dict[str, Any],
    student_db_id: int,
    distance: float,
    margin: float,
) -> tuple[bool, int, float]:
    """
    Confirm identity across multiple API observations.

    IMPORTANT FIX:
    Confirmation is keyed primarily by student_db_id, not only by
    track_id. The tracker is still used for stable boxes, but a small
    detector-box change must NOT reset recognition from observation 2 back
    to observation 1.

    This is the key reason the old implementation could stay forever at
    "Recognizing..." even when the same person was continuously visible.
    """
    now = time.time()

    observations = state.setdefault(
        "student_observations",
        {},
    )

    key = str(student_db_id)
    item = observations.get(key)

    if (
        item is None
        or now - item["first_seen"] > TEMPORAL_WINDOW_SECONDS
    ):
        item = {
            "student_db_id": student_db_id,
            "first_seen": now,
            "last_seen": now,
            "count": 0,
            "distances": [],
            "margins": [],
            "last_track_id": face.get("track_id"),
        }

    item["last_seen"] = now
    item["count"] += 1
    item["distances"].append(float(distance))
    item["margins"].append(float(margin))
    item["last_track_id"] = face.get("track_id")

    item["distances"] = item["distances"][-10:]
    item["margins"] = item["margins"][-10:]

    observations[key] = item

    average_margin = float(np.mean(item["margins"]))
    average_distance = float(np.mean(item["distances"]))

    # If there is only one registered student, margin is normally 1.0.
    # Otherwise require the configured separation margin.
    margin_ok = (
        average_margin >= MARGIN_THRESHOLD
        or not math.isfinite(margin)
        or item["count"] >= TEMPORAL_REQUIRED + 1
    )

    confirmed = (
        item["count"] >= TEMPORAL_REQUIRED
        and margin_ok
    )

    return (
        confirmed,
        int(item["count"]),
        average_distance,
    )


# ============================================================
# ATTENDANCE
# ============================================================

def clamp_threshold(value: float) -> float:
    return max(0.20, min(0.75, float(value)))


def mark_attendance(
    session: dict[str, Any],
    student: dict[str, Any],
    distance: float,
    video_timestamp: Optional[float],
) -> bool:
    session_id = int(session["id"])
    student_db_id = int(student["id"])

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(
                """
                SELECT id
                FROM attendance
                WHERE session_id=%s
                  AND student_db_id=%s
                LIMIT 1
                """,
                (session_id, student_db_id),
            )

            if cur.fetchone():
                return False

            confidence = max(
                0.0,
                min(
                    1.0,
                    1.0 - float(distance),
                ),
            )

            cur.execute(
                """
                INSERT INTO attendance
                (
                    session_id,
                    student_db_id,
                    marked_at,
                    distance,
                    confidence,
                    method,
                    video_timestamp
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    session_id,
                    student_db_id,
                    now_dt(),
                    float(distance),
                    confidence,
                    "yolo+sahi+arcface",
                    video_timestamp,
                ),
            )

            conn.commit()
        finally:
            conn.close()

    add_activity(
        "Attendance completed",
        f"{student['name']} marked present using "
        "YOLO + SAHI + ArcFace.",
    )

    return True


# ============================================================
# FRAME RECOGNITION
# ============================================================

def process_frame_for_session(
    frame: np.ndarray,
    session: dict[str, Any],
    source_type: str = "webcam",
    video_timestamp: Optional[float] = None,
) -> tuple[np.ndarray, list[dict[str, Any]]]:
    require_ai()

    working = resize_for_ai(frame.copy())

    faces, detector_meta = detect_faces(
        working,
        source_type,
    )

    class_name = session["class_name"]
    division = session["division"]

    students = load_students(
        class_name,
        division,
    )

    threshold = clamp_threshold(
        float(session["threshold"])
    )

    if source_type.lower() in {
        "video",
        "rtsp",
        "cctv",
    }:
        threshold = min(
            threshold,
            VIDEO_THRESHOLD,
        )

    state = SESSION_STATE.setdefault(
        int(session["id"]),
        {
            "observations": {},
            "student_observations": {},
            "tracks": [],
        },
    )

    tracks, faces = update_tracks(
        state["tracks"],
        faces,
    )
    state["tracks"] = tracks

    results: list[dict[str, Any]] = []
    confirmed_candidates: list[
        tuple[float, int, dict[str, Any]]
    ] = []

    for face in faces:
        result: dict[str, Any] = {
            **face,
            "student_id": None,
            "name": "Unknown",
            "label": "Unknown",
            "matched": False,
            "confirmed": False,
            "distance": None,
            "best_distance": None,
            "second_best_distance": None,
            "margin": None,
            "confidence": 0.0,
            "attendance_marked": False,
            "reason": "No match.",
            "detector": face.get(
                "source",
                "yolo",
            ),
            "sahi_used": bool(
                detector_meta["sahi_used"]
            ),
        }

        aligned = align_face(
            working,
            face,
        )

        quality, quality_meta = calculate_quality(
            aligned
        )

        result["quality"] = round(
            quality,
            2,
        )
        result["quality_details"] = quality_meta

        if quality < MIN_FACE_QUALITY:
            result["reason"] = "Face quality too low."
            results.append(result)
            continue

        try:
            query_embedding = embedding_from_crop(
                aligned
            )
        except Exception as exc:
            result["reason"] = (
                f"Embedding failed: {exc}"
            )
            results.append(result)
            continue

        match = best_gallery_match(
            query_embedding,
            students,
        )

        best_student = match["student"]
        best_distance = match["best_distance"]
        second_best = match["second_best_distance"]
        margin = match["margin"]

        result["best_distance"] = (
            round(best_distance, 5)
            if math.isfinite(best_distance)
            else None
        )
        result["second_best_distance"] = (
            round(second_best, 5)
            if math.isfinite(second_best)
            else None
        )
        result["margin"] = (
            round(margin, 5)
            if math.isfinite(margin)
            else None
        )

        if best_student is None:
            result["reason"] = "No registered embeddings."
            results.append(result)
            continue

        accepted = (
            best_distance <= threshold
            and (
                not math.isfinite(second_best)
                or margin >= MARGIN_THRESHOLD
            )
        )

        if not accepted:
            result["reason"] = (
                "Match rejected by threshold/margin."
            )
            results.append(result)
            continue

        confirmed, observations, average_distance = (
            temporal_confirmation(
                state,
                face,
                int(best_student["id"]),
                best_distance,
                margin,
            )
        )

        result.update(
            {
                "student_id": best_student["student_id"],
                "name": best_student["name"],
                "label": best_student["name"],
                "matched": True,
                "confirmed": confirmed,
                "distance": round(
                    average_distance,
                    5,
                ),
                "confidence": round(
                    max(
                        0.0,
                        min(
                            1.0,
                            1.0 - average_distance,
                        ),
                    )
                    * 100.0,
                    2,
                ),
                "observations": observations,
                "reason": (
                    "Identity confirmed."
                    if confirmed
                    else "Awaiting temporal confirmation."
                ),
            }
        )

        results.append(result)

        if confirmed:
            confirmed_candidates.append(
                (
                    best_distance,
                    len(results) - 1,
                    best_student,
                )
            )

    # One student cannot be claimed by two tracks in the same frame.
    claimed_students: set[int] = set()

    confirmed_candidates.sort(
        key=lambda item: item[0]
    )

    for distance, result_index, student in (
        confirmed_candidates
    ):
        student_db_id = int(student["id"])

        if student_db_id in claimed_students:
            results[result_index].update(
                {
                    "student_id": None,
                    "name": "Unknown",
                    "label": "Unknown",
                    "matched": False,
                    "confirmed": False,
                    "reason": (
                        "Duplicate identity claim in frame."
                    ),
                }
            )
            continue

        claimed_students.add(student_db_id)

        marked = mark_attendance(
            session,
            student,
            distance,
            video_timestamp,
        )

        results[result_index][
            "attendance_marked"
        ] = bool(marked)

    return working, results


# ============================================================
# REQUEST MODELS
# ============================================================

class SessionBody(BaseModel):
    class_name: str = Field(
        min_length=1,
        max_length=120,
    )
    division: str = Field(
        min_length=1,
        max_length=40,
    )
    subject: str = Field(
        min_length=1,
        max_length=160,
    )
    room: str = Field(
        min_length=1,
        max_length=120,
    )
    source_type: str = Field(
        default="webcam",
        min_length=1,
        max_length=40,
    )
    threshold: float = DEFAULT_FACE_THRESHOLD


class EndSessionBody(BaseModel):
    session_id: int


class RTSPBody(BaseModel):
    url: str = Field(
        min_length=8,
        max_length=1000,
    )
    session_id: Optional[int] = None
    threshold: float = DEFAULT_FACE_THRESHOLD


# ============================================================
# LIFESPAN / APP
# ============================================================

@asynccontextmanager
async def lifespan(_app: FastAPI):
    print("=" * 72)
    print(" AI FACE RECOGNITION ATTENDANCE SYSTEM")
    print(" YOLO + SAHI + ArcFace + MySQL")
    print("=" * 72)

    try:
        if not mysql_password_loaded():
            print(
                "[MySQL] WARNING: MYSQL_PASSWORD is empty. "
                "Set it in .env before connecting."
            )
        initialize_database()
        print(
            f"[MySQL] Ready: {MYSQL_HOST}:{MYSQL_PORT}/"
            f"{MYSQL_DATABASE}"
        )
    except Exception as exc:
        print(f"[MySQL] ERROR: {exc}")

    warmup_arcface()
    load_yolo_model()
    load_sahi_model()

    print(
        f"[ArcFace] {'Ready' if ARCFACE_READY else 'NOT READY'}"
    )
    print(
        f"[YOLO] {'Ready' if YOLO_READY else 'NOT READY'}"
    )
    print(
        f"[SAHI] {'Ready' if SAHI_READY else 'NOT READY'}"
    )
    print(
        f"[Low-light] {'Enabled' if LOW_LIGHT_ENABLED else 'Disabled'}"
    )
    print(
        f"[Upscaling] {'Enabled' if UPSCALE_ENABLED else 'Disabled'}"
    )
    print("=" * 72)

    yield

    with RTSP_LOCK:
        states = list(RTSP_STREAMS.values())

    for state in states:
        try:
            state["stop"].set()
        except Exception:
            pass


app = FastAPI(
    title="AI Face Recognition Attendance API",
    version="8.1.0-YOLO-SAHI-ARCFACE-MYSQL-TEMPORAL-FIX",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# FRONTEND
# ============================================================

@app.get("/")
def root():
    index_file = (
        PROJECT_ROOT / "frontend" / "index.html"
    )

    if not index_file.is_file():
        raise HTTPException(
            404,
            "frontend/index.html not found.",
        )

    return FileResponse(index_file)


@app.get("/assets/{path:path}")
def assets(path: str):
    target = (
        PROJECT_ROOT / "frontend" / "assets" / path
    )

    if not target.is_file():
        raise HTTPException(
            404,
            "Asset not found.",
        )

    return FileResponse(target)


# ============================================================
# HEALTH
# ============================================================

@app.get("/api/health")
def health():
    embedding_count = 0
    student_count = 0

    try:
        with DB_LOCK:
            conn = db()
            try:
                cur = conn.cursor()
                cur.execute(
                    "SELECT COUNT(*) FROM students"
                )
                student_count = int(
                    cur.fetchone()[0]
                )
                cur.execute(
                    "SELECT COUNT(*) FROM face_embeddings"
                )
                embedding_count = int(
                    cur.fetchone()[0]
                )
            finally:
                conn.close()
    except Exception:
        pass

    return {
        "ok": True,
        "database": "mysql",
        "database_host": MYSQL_HOST,
        "database_name": MYSQL_DATABASE,
        "model": ARCFACE_MODEL_NAME,
        "detector": "YOLO-face",
        "small_face_detector": (
            "SAHI + YOLO"
            if SAHI_ENABLED
            else "YOLO"
        ),
        "distance_metric": ARCFACE_DISTANCE_METRIC,
        "arcface_ready": ARCFACE_READY,
        "yolo_ready": YOLO_READY,
        "sahi_ready": SAHI_READY,
        "recognition_ready": (
            ARCFACE_READY and YOLO_READY
        ),
        "student_count": student_count,
        "embedding_count": embedding_count,
        "embedding_dimension": EMBEDDING_DIMENSION,
        "threshold": DEFAULT_FACE_THRESHOLD,
        "margin_threshold": MARGIN_THRESHOLD,
        "low_light_enabled": LOW_LIGHT_ENABLED,
        "upscale_enabled": UPSCALE_ENABLED,
        "yolo_model": YOLO_MODEL_PATH,
        "yolo_input_size": YOLO_INPUT_SIZE,
        "error": (
            ARCFACE_ERROR
            or YOLO_ERROR
            or SAHI_ERROR
            or ""
        ),
    }


# ============================================================
# STUDENTS
# ============================================================

@app.get("/api/students")
def students_api():
    try:
        with DB_LOCK:
            conn = db()
            try:
                cur = conn.cursor(dictionary=True)
                cur.execute("""
                    SELECT
                        s.id,
                        s.student_id,
                        s.name,
                        s.class_name,
                        s.division,
                        s.email,
                        s.phone,
                        s.photo_data,
                        COUNT(DISTINCT e.id) AS embedding_count,
                        COUNT(DISTINCT a.id) AS present_count,
                        COUNT(DISTINCT se.id) AS total_sessions
                    FROM students s
                    LEFT JOIN face_embeddings e
                        ON e.student_db_id=s.id
                    LEFT JOIN attendance a
                        ON a.student_db_id=s.id
                    LEFT JOIN attendance_sessions se
                        ON se.class_name=s.class_name
                       AND se.division=s.division
                    GROUP BY
                        s.id,
                        s.student_id,
                        s.name,
                        s.class_name,
                        s.division,
                        s.email,
                        s.phone,
                        s.photo_data
                    ORDER BY s.id DESC
                """)
                rows = cur.fetchall()
            finally:
                conn.close()

        return [
            {
                "id": int(row["id"]),
                "student_id": row["student_id"],
                "name": row["name"],
                "cls": row["class_name"],
                "class_name": row["class_name"],
                "division": row["division"],
                "email": row["email"] or "",
                "phone": row["phone"] or "",
                "photo": row["photo_data"] or "",
                "face": int(row["embedding_count"]) > 0,
                "embedding_count": int(
                    row["embedding_count"]
                ),
                "present_count": int(
                    row["present_count"]
                ),
                "total_sessions": int(
                    row["total_sessions"]
                ),
            }
            for row in rows
        ]
    except Exception as exc:
        raise HTTPException(
            500,
            f"Unable to load students: {exc}",
        ) from exc


@app.post("/api/students")
async def create_student(
    student_id: str = Form(...),
    name: str = Form(...),
    class_name: str = Form(...),
    division: str = Form(...),
    email: str = Form(""),
    phone: str = Form(""),
    image: UploadFile = File(...),
):
    require_ai()

    student_id = student_id.strip()
    name = name.strip()
    class_name = class_name.strip()
    division = division.strip()
    email = email.strip()
    phone = phone.strip()

    if not student_id or not name:
        raise HTTPException(
            400,
            "Student ID and name are required.",
        )

    frame = decode_image(
        await image.read()
    )

    faces, _ = detect_faces(
        frame,
        "registration",
    )

    if len(faces) != 1:
        raise HTTPException(
            422,
            "Registration image must contain exactly one face.",
        )

    aligned = align_face(
        frame,
        faces[0],
    )

    quality, quality_meta = calculate_quality(
        aligned
    )

    if quality < MIN_FACE_QUALITY:
        raise HTTPException(
            422,
            "Face quality is too low for registration.",
        )

    try:
        embeddings = build_registration_embeddings(
            aligned
        )
    except Exception as exc:
        raise HTTPException(
            500,
            f"ArcFace embedding generation failed: {exc}",
        ) from exc

    ok, encoded = cv2.imencode(
        ".jpg",
        frame,
        [cv2.IMWRITE_JPEG_QUALITY, 90],
    )

    if not ok:
        raise HTTPException(
            500,
            "Unable to encode student photo.",
        )

    photo = (
        "data:image/jpeg;base64,"
        + base64.b64encode(
            encoded.tobytes()
        ).decode("ascii")
    )

    stamp = now_dt()

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT id FROM students
                WHERE student_id=%s
                LIMIT 1
                """,
                (student_id,),
            )

            if cur.fetchone():
                raise HTTPException(
                    409,
                    "Student ID already exists.",
                )

            cur.execute(
                """
                INSERT INTO students
                (
                    student_id,
                    name,
                    class_name,
                    division,
                    email,
                    phone,
                    photo_data,
                    created_at,
                    updated_at
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    student_id,
                    name,
                    class_name,
                    division,
                    email,
                    phone,
                    photo,
                    stamp,
                    stamp,
                ),
            )

            db_id = int(cur.lastrowid)

            for embedding in embeddings:
                cur.execute(
                    """
                    INSERT INTO face_embeddings
                    (
                        student_db_id,
                        embedding_vector,
                        model_name,
                        embedding_dimension,
                        created_at
                    )
                    VALUES (%s,%s,%s,%s,%s)
                    """,
                    (
                        db_id,
                        embedding_to_blob(embedding),
                        ARCFACE_MODEL_NAME,
                        EMBEDDING_DIMENSION,
                        stamp,
                    ),
                )

            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    clear_student_cache()

    add_activity(
        "Student registered",
        f"{name} registered using YOLO + SAHI + ArcFace.",
    )

    return {
        "ok": True,
        "student_id": student_id,
        "db_id": db_id,
        "name": name,
        "cls": class_name,
        "class_name": class_name,
        "division": division,
        "email": email,
        "phone": phone,
        "face": True,
        "photo": photo,
        "quality": round(quality, 2),
        "quality_details": quality_meta,
        "embedding_dimension": EMBEDDING_DIMENSION,
        "embedding_count": len(embeddings),
        "message": (
            "Student registered successfully with "
            "YOLO + SAHI + ArcFace."
        ),
    }


@app.put("/api/students/{student_id}")
async def update_student(
    student_id: str,
    name: str = Form(...),
    class_name: str = Form(...),
    division: str = Form(...),
    email: str = Form(""),
    phone: str = Form(""),
    image: Optional[UploadFile] = File(None),
):
    name = name.strip()
    class_name = class_name.strip()
    division = division.strip()
    email = email.strip()
    phone = phone.strip()

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(
                """
                SELECT *
                FROM students
                WHERE student_id=%s
                LIMIT 1
                """,
                (student_id,),
            )
            existing = cur.fetchone()
        finally:
            conn.close()

    if existing is None:
        raise HTTPException(
            404,
            "Student not found.",
        )

    photo = existing["photo_data"] or ""

    if image is not None and image.filename:
        require_ai()

        frame = decode_image(
            await image.read()
        )

        faces, _ = detect_faces(
            frame,
            "registration",
        )

        if len(faces) != 1:
            raise HTTPException(
                422,
                "Update image must contain exactly one face.",
            )

        aligned = align_face(
            frame,
            faces[0],
        )

        quality, quality_meta = calculate_quality(
            aligned
        )

        if quality < MIN_FACE_QUALITY:
            raise HTTPException(
                422,
                "Face quality is too low.",
            )

        embeddings = build_registration_embeddings(
            aligned
        )

        ok, encoded = cv2.imencode(
            ".jpg",
            frame,
            [cv2.IMWRITE_JPEG_QUALITY, 90],
        )

        if ok:
            photo = (
                "data:image/jpeg;base64,"
                + base64.b64encode(
                    encoded.tobytes()
                ).decode("ascii")
            )
        else:
            raise HTTPException(
                500,
                "Unable to encode updated photo.",
            )
    else:
        embeddings = None

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor()

            cur.execute(
                """
                UPDATE students
                SET
                    name=%s,
                    class_name=%s,
                    division=%s,
                    email=%s,
                    phone=%s,
                    photo_data=%s,
                    updated_at=%s
                WHERE student_id=%s
                """,
                (
                    name,
                    class_name,
                    division,
                    email,
                    phone,
                    photo,
                    now_dt(),
                    student_id,
                ),
            )

            if embeddings is not None:
                cur.execute(
                    """
                    SELECT id
                    FROM students
                    WHERE student_id=%s
                    LIMIT 1
                    """,
                    (student_id,),
                )
                row = cur.fetchone()
                db_id = int(row[0])

                cur.execute(
                    """
                    DELETE FROM face_embeddings
                    WHERE student_db_id=%s
                    """,
                    (db_id,),
                )

                for embedding in embeddings:
                    cur.execute(
                        """
                        INSERT INTO face_embeddings
                        (
                            student_db_id,
                            embedding_vector,
                            model_name,
                            embedding_dimension,
                            created_at
                        )
                        VALUES (%s,%s,%s,%s,%s)
                        """,
                        (
                            db_id,
                            embedding_to_blob(embedding),
                            ARCFACE_MODEL_NAME,
                            EMBEDDING_DIMENSION,
                            now_dt(),
                        ),
                    )

            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    clear_student_cache()

    add_activity(
        "Student updated",
        f"{name} details were updated.",
    )

    return {
        "ok": True,
        "student_id": student_id,
        "name": name,
        "cls": class_name,
        "class_name": class_name,
        "division": division,
        "email": email,
        "phone": phone,
        "photo": photo,
        "message": "Student updated successfully.",
    }


@app.delete("/api/students/{student_id}")
def delete_student(student_id: str):
    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(
                """
                SELECT name
                FROM students
                WHERE student_id=%s
                LIMIT 1
                """,
                (student_id,),
            )
            row = cur.fetchone()

            if not row:
                raise HTTPException(
                    404,
                    "Student not found.",
                )

            cur.execute(
                """
                DELETE FROM students
                WHERE student_id=%s
                """,
                (student_id,),
            )
            conn.commit()
        finally:
            conn.close()

    clear_student_cache()

    add_activity(
        "Student deleted",
        f"{row['name']} was removed.",
    )

    return {"ok": True}


# ============================================================
# SESSIONS
# ============================================================

@app.post("/api/sessions")
def create_session(body: SessionBody):
    threshold = clamp_threshold(
        body.threshold
    )

    source = body.source_type.strip().lower()

    if source in {
        "video",
        "rtsp",
        "cctv",
    }:
        threshold = min(
            threshold,
            VIDEO_THRESHOLD,
        )

    key = uuid.uuid4().hex

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor()

            cur.execute(
                """
                INSERT INTO attendance_sessions
                (
                    session_key,
                    class_name,
                    division,
                    subject,
                    room,
                    source_type,
                    threshold,
                    started_at
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                """,
                (
                    key,
                    body.class_name.strip(),
                    body.division.strip(),
                    body.subject.strip(),
                    body.room.strip(),
                    source,
                    threshold,
                    now_dt(),
                ),
            )

            sid = int(cur.lastrowid)
            conn.commit()
        finally:
            conn.close()

    SESSION_STATE[sid] = {
        "observations": {},
        "student_observations": {},
        "tracks": [],
    }

    add_activity(
        "Attendance session",
        f"{body.subject} session started in {body.room}.",
    )

    return {
        "ok": True,
        "session_id": sid,
        "threshold": threshold,
        "model": ARCFACE_MODEL_NAME,
        "detector": "YOLO + SAHI",
        "source_type": source,
    }


@app.post("/api/sessions/end")
def end_session(body: EndSessionBody):
    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                UPDATE attendance_sessions
                SET ended_at=%s
                WHERE id=%s
                  AND ended_at IS NULL
                """,
                (now_dt(), body.session_id),
            )
            conn.commit()
        finally:
            conn.close()

    SESSION_STATE.pop(
        body.session_id,
        None,
    )

    return {"ok": True}


# ============================================================
# RECOGNITION / DETECTION
# ============================================================

@app.post("/api/recognition/frame")
async def recognition_frame(
    session_id: int = Form(...),
    frame: UploadFile = File(...),
    video_timestamp: Optional[float] = Form(None),
):
    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(
                """
                SELECT *
                FROM attendance_sessions
                WHERE id=%s
                LIMIT 1
                """,
                (session_id,),
            )
            session = cur.fetchone()
        finally:
            conn.close()

    if not session or session["ended_at"] is not None:
        raise HTTPException(
            409,
            "Attendance session is not active.",
        )

    image = decode_image(
        await frame.read()
    )

    processed, faces = process_frame_for_session(
        image,
        session,
        session["source_type"],
        video_timestamp,
    )

    return {
        "ok": True,
        "width": int(processed.shape[1]),
        "height": int(processed.shape[0]),
        "face_count": len(faces),
        "faces": faces,
        "model": ARCFACE_MODEL_NAME,
        "detector": "YOLO + SAHI",
        "video_timestamp": video_timestamp,
        "temporal_required": TEMPORAL_REQUIRED,
        "temporal_window_seconds": TEMPORAL_WINDOW_SECONDS,
    }


@app.post("/api/detection/frame")
async def detection_frame(
    frame: UploadFile = File(...),
):
    require_ai()

    image = decode_image(
        await frame.read()
    )

    faces, meta = detect_faces(
        image,
        "webcam",
    )

    return {
        "ok": True,
        "width": int(image.shape[1]),
        "height": int(image.shape[0]),
        "face_count": len(faces),
        "faces": faces,
        "detector": "YOLO + SAHI",
        "detection": meta,
    }


# ============================================================
# ATTENDANCE HISTORY
# ============================================================

@app.get("/api/attendance")
def attendance_api(
    from_date: str = "",
    to_date: str = "",
    class_name: str = "",
    division: str = "",
    subject: str = "",
    student: str = "",
    room: str = "",
    status: str = "",
):
    if status and status.lower() != "present":
        return []

    clauses = ["1=1"]
    params: list[Any] = []

    if from_date:
        clauses.append(
            "DATE(a.marked_at) >= %s"
        )
        params.append(from_date)

    if to_date:
        clauses.append(
            "DATE(a.marked_at) <= %s"
        )
        params.append(to_date)

    if class_name:
        clauses.append(
            "s.class_name=%s"
        )
        params.append(class_name)

    if division:
        clauses.append(
            "s.division=%s"
        )
        params.append(division)

    if subject:
        clauses.append(
            "se.subject=%s"
        )
        params.append(subject)

    if student:
        clauses.append(
            "(s.name LIKE %s OR s.student_id LIKE %s)"
        )
        params.extend(
            [
                f"%{student}%",
                f"%{student}%",
            ]
        )

    if room:
        clauses.append(
            "se.room LIKE %s"
        )
        params.append(
            f"%{room}%"
        )

    sql = f"""
        SELECT
            a.id,
            DATE(a.marked_at) AS attendance_date,
            s.student_id,
            s.name,
            s.class_name,
            s.division,
            se.subject,
            'Present' AS status,
            TIME(a.marked_at) AS marked_time,
            se.room,
            a.distance,
            a.confidence
        FROM attendance a
        JOIN students s
          ON s.id=a.student_db_id
        JOIN attendance_sessions se
          ON se.id=a.session_id
        WHERE {' AND '.join(clauses)}
        ORDER BY a.marked_at DESC
    """

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql, params)
            rows = cur.fetchall()
        finally:
            conn.close()

    return [
        {
            **row,
            "id": int(row["id"]),
            "distance": float(row["distance"]),
            "confidence": float(row["confidence"]),
        }
        for row in rows
    ]


# ============================================================
# ACTIVITIES / DASHBOARD
# ============================================================

@app.get("/api/activities")
def activities_api():
    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(
                """
                SELECT
                    activity_type,
                    message,
                    created_at
                FROM activities
                ORDER BY id DESC
                LIMIT 30
                """
            )
            rows = cur.fetchall()
        finally:
            conn.close()

    return rows


@app.get("/api/dashboard")
def dashboard_api():
    today = datetime.now(
        timezone.utc
    ).date()

    with DB_LOCK:
        conn = db()
        try:
            cur = conn.cursor(dictionary=True)

            cur.execute(
                "SELECT COUNT(*) AS total FROM students"
            )
            total = int(
                cur.fetchone()["total"]
            )

            cur.execute(
                """
                SELECT COUNT(DISTINCT student_db_id) AS present
                FROM attendance
                WHERE DATE(marked_at)=%s
                """,
                (today,),
            )
            present = int(
                cur.fetchone()["present"]
            )

            cur.execute(
                """
                SELECT
                    s.class_name,
                    s.division,
                    COUNT(DISTINCT s.id) AS total,
                    COUNT(
                        DISTINCT CASE
                            WHEN DATE(a.marked_at)=%s
                            THEN a.student_db_id
                        END
                    ) AS present
                FROM students s
                LEFT JOIN attendance a
                    ON a.student_db_id=s.id
                GROUP BY
                    s.class_name,
                    s.division
                ORDER BY
                    s.class_name,
                    s.division
                """,
                (today,),
            )
            class_rows = cur.fetchall()

            cur.execute(
                """
                SELECT
                    s.id,
                    COUNT(DISTINCT se.id) AS sessions,
                    COUNT(DISTINCT a.id) AS present
                FROM students s
                LEFT JOIN attendance_sessions se
                    ON se.class_name=s.class_name
                   AND se.division=s.division
                LEFT JOIN attendance a
                    ON a.session_id=se.id
                   AND a.student_db_id=s.id
                GROUP BY s.id
                """
            )
            rates = cur.fetchall()

            trend: list[int] = []

            for offset in range(6, -1, -1):
                day = (
                    today
                    - timedelta(days=offset)
                )

                cur.execute(
                    """
                    SELECT COUNT(
                        DISTINCT student_db_id
                    ) AS count
                    FROM attendance
                    WHERE DATE(marked_at)=%s
                    """,
                    (day,),
                )

                count = int(
                    cur.fetchone()["count"]
                )

                trend.append(
                    round(
                        count / total * 100
                    )
                    if total
                    else 0
                )
        finally:
            conn.close()

    class_data = []

    for row in class_rows:
        class_total = int(
            row["total"]
        )
        class_present = int(
            row["present"]
        )

        class_data.append(
            {
                "class_name": row["class_name"],
                "division": row["division"],
                "total": class_total,
                "present": class_present,
                "percentage": round(
                    class_present
                    / class_total
                    * 100
                )
                if class_total
                else 0,
            }
        )

    average = (
        round(
            sum(
                (
                    int(row["present"])
                    / int(row["sessions"])
                    * 100
                )
                if int(row["sessions"])
                else 0
                for row in rates
            )
            / len(rates)
        )
        if rates
        else 0
    )

    return {
        "total_students": total,
        "present_today": present,
        "attendance_today": (
            round(
                present / total * 100
            )
            if total
            else 0
        ),
        "average_attendance": average,
        "classes": class_data,
        "trend": trend,
    }


# ============================================================
# RECORDINGS
# ============================================================

@app.post("/api/recordings")
async def upload_recording(
    video: UploadFile = File(...),
):
    suffix = Path(
        video.filename or ""
    ).suffix.lower()

    allowed = {
        ".mp4",
        ".mov",
        ".avi",
        ".mkv",
        ".webm",
    }

    if suffix not in allowed:
        raise HTTPException(
            400,
            "Unsupported video format. "
            "Use MP4, MOV, AVI, MKV or WebM.",
        )

    target = (
        RECORDINGS_DIR
        / (uuid.uuid4().hex + suffix)
    )

    with target.open("wb") as output:
        while True:
            chunk = await video.read(
                1024 * 1024
            )

            if not chunk:
                break

            output.write(chunk)

    return {
        "ok": True,
        "filename": target.name,
    }


@app.get("/api/recordings")
def recordings():
    return [
        {
            "filename": path.name,
            "size": path.stat().st_size,
        }
        for path in RECORDINGS_DIR.iterdir()
        if path.is_file()
    ]


@app.get("/api/recordings/{filename}")
def recording_file(filename: str):
    safe_name = Path(filename).name
    target = RECORDINGS_DIR / safe_name

    if not target.is_file():
        raise HTTPException(
            404,
            "Recording not found.",
        )

    return FileResponse(target)


# ============================================================
# RTSP / CCTV
# ============================================================

def _open_rtsp_capture(url: str):
    backends = []

    if hasattr(cv2, "CAP_FFMPEG"):
        backends.append(cv2.CAP_FFMPEG)

    backends.append(cv2.CAP_ANY)

    for backend in backends:
        try:
            cap = cv2.VideoCapture(
                url,
                backend,
            )

            if cap.isOpened():
                try:
                    cap.set(
                        cv2.CAP_PROP_BUFFERSIZE,
                        1,
                    )
                except Exception:
                    pass

                return cap

            cap.release()
        except Exception:
            continue

    return None


def rtsp_worker(stream_id: str):
    state = RTSP_STREAMS[stream_id]

    cap = None
    next_ai = 0.0

    try:
        while not state["stop"].is_set():
            if cap is None or not cap.isOpened():
                if cap is not None:
                    try:
                        cap.release()
                    except Exception:
                        pass

                cap = _open_rtsp_capture(
                    state["url"]
                )
                state["cap"] = cap

                if cap is None:
                    state["error"] = (
                        "CCTV connection failed; retrying."
                    )
                    time.sleep(1.0)
                    continue

                state["error"] = ""

            ok, frame = cap.read()

            if not ok or frame is None:
                state["error"] = (
                    "CCTV frame read failed; reconnecting."
                )

                try:
                    cap.release()
                except Exception:
                    pass

                cap = None
                time.sleep(0.5)
                continue

            now = time.time()

            if now < next_ai:
                continue

            next_ai = now + (
                RECOGNITION_INTERVAL
                if state.get("session_id")
                else 1.0
            )

            sid = state.get("session_id")

            if not sid:
                state["latest_frame"] = frame
                continue

            try:
                with DB_LOCK:
                    conn = db()
                    try:
                        cur = conn.cursor(
                            dictionary=True
                        )
                        cur.execute(
                            """
                            SELECT *
                            FROM attendance_sessions
                            WHERE id=%s
                            LIMIT 1
                            """,
                            (sid,),
                        )
                        session = cur.fetchone()
                    finally:
                        conn.close()

                if (
                    session
                    and session["ended_at"] is None
                ):
                    processed, faces = (
                        process_frame_for_session(
                            frame,
                            session,
                            "rtsp",
                        )
                    )

                    state["latest_frame"] = processed
                    state["latest_faces"] = faces
                    state["last_processed"] = time.time()
                else:
                    state["session_id"] = None

            except Exception as exc:
                state["error"] = str(exc)

    finally:
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass

        state["cap"] = None


@app.post("/api/rtsp/start")
def start_rtsp(body: RTSPBody):
    stream_id = uuid.uuid4().hex[:12]

    stop_event = threading.Event()

    state = {
        "id": stream_id,
        "url": body.url,
        "session_id": body.session_id,
        "threshold": body.threshold,
        "stop": stop_event,
        "cap": None,
        "latest_frame": None,
        "latest_faces": [],
        "last_processed": None,
        "error": "",
    }

    with RTSP_LOCK:
        RTSP_STREAMS[stream_id] = state

    thread = threading.Thread(
        target=rtsp_worker,
        args=(stream_id,),
        daemon=True,
        name=f"RTSP-{stream_id}",
    )

    state["thread"] = thread
    thread.start()

    return {
        "ok": True,
        "stream_id": stream_id,
        "message": "RTSP stream started.",
    }


@app.post("/api/rtsp/stop/{stream_id}")
def stop_rtsp(stream_id: str):
    with RTSP_LOCK:
        state = RTSP_STREAMS.get(stream_id)

        if not state:
            raise HTTPException(
                404,
                "RTSP stream not found.",
            )

        state["stop"].set()

    return {
        "ok": True,
        "message": "RTSP stream stopping.",
    }


@app.get("/api/rtsp/{stream_id}/status")
def rtsp_status(stream_id: str):
    with RTSP_LOCK:
        state = RTSP_STREAMS.get(stream_id)

        if not state:
            raise HTTPException(
                404,
                "RTSP stream not found.",
            )

        return {
            "ok": True,
            "stream_id": stream_id,
            "session_id": state.get(
                "session_id"
            ),
            "last_processed": state.get(
                "last_processed"
            ),
            "faces": state.get(
                "latest_faces",
                [],
            ),
            "error": state.get(
                "error",
                "",
            ),
            "running": not state["stop"].is_set(),
        }


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=os.getenv(
            "HOST",
            "0.0.0.0",
        ),
        port=int(
            os.getenv(
                "PORT",
                "8000",
            )
        ),
        reload=False,
    )
