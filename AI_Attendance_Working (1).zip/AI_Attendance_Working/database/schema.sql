CREATE DATABASE IF NOT EXISTS ai_attendance CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ai_attendance;

CREATE TABLE IF NOT EXISTS students (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_id VARCHAR(100) NOT NULL,
  name VARCHAR(160) NOT NULL,
  class_name VARCHAR(120) NOT NULL,
  division VARCHAR(40) NOT NULL,
  email VARCHAR(255) DEFAULT '',
  phone VARCHAR(50) DEFAULT '',
  photo_data LONGTEXT,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_students_student_id (student_id),
  KEY idx_students_class_div (class_name, division)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS face_embeddings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_db_id BIGINT UNSIGNED NOT NULL,
  embedding_vector BLOB NOT NULL,
  model_name VARCHAR(80) NOT NULL,
  embedding_dimension INT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_embeddings_student (student_db_id),
  CONSTRAINT fk_embeddings_student FOREIGN KEY (student_db_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_key VARCHAR(64) NOT NULL,
  class_name VARCHAR(120) NOT NULL,
  division VARCHAR(40) NOT NULL,
  subject VARCHAR(160) NOT NULL,
  room VARCHAR(120) NOT NULL,
  source_type VARCHAR(40) NOT NULL,
  threshold DOUBLE NOT NULL,
  started_at DATETIME(6) NOT NULL,
  ended_at DATETIME(6) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_session_key (session_key),
  KEY idx_sessions_class_div (class_name, division)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attendance (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id BIGINT UNSIGNED NOT NULL,
  student_db_id BIGINT UNSIGNED NOT NULL,
  marked_at DATETIME(6) NOT NULL,
  distance DOUBLE NOT NULL,
  confidence DOUBLE NOT NULL,
  method VARCHAR(80) NOT NULL,
  video_timestamp DOUBLE NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_session_student (session_id, student_db_id),
  KEY idx_attendance_date (marked_at),
  CONSTRAINT fk_attendance_session FOREIGN KEY (session_id) REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  CONSTRAINT fk_attendance_student FOREIGN KEY (student_db_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activities (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  activity_type VARCHAR(100) NOT NULL,
  message VARCHAR(500) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_activity_created (created_at)
) ENGINE=InnoDB;
