Place the YOLO face model here:

    yolov8n-face.pt

The project expects this exact path:

    models\yolov8n-face.pt

The setup script can download the model automatically if PowerShell/network access is available.
