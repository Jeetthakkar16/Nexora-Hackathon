@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo AI Face Recognition Attendance System - Setup
echo ================================================
py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.11 was not found.
  echo Install Python 3.11 and run this file again.
  pause
  exit /b 1
)
if not exist "venv\Scripts\python.exe" (
  echo Creating Python 3.11 virtual environment...
  py -3.11 -m venv venv
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist ".env" copy ".env.example" ".env" >nul
if not exist "models\yolov8n-face.pt" (
  echo Downloading YOLOv8n-Face model...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://github.com/YapaLab/yolo-face/releases/download/1.0.0/yolov8n-face.pt' -OutFile 'models\yolov8n-face.pt'"
  if errorlevel 1 echo Model download failed. Put yolov8n-face.pt in models manually.
)
echo.
echo Setup complete.
echo Next: edit .env and set MYSQL_PASSWORD to your actual MySQL root password.
echo Then run start.bat
pause
