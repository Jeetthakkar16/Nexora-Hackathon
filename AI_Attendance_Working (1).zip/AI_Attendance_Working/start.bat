@echo off
setlocal
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" (
  echo Virtual environment not found.
  echo Run setup.bat first.
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created .env from .env.example.
)
findstr /C:"PUT_YOUR_MYSQL_ROOT_PASSWORD_HERE" .env >nul
if %errorlevel%==0 (
  echo.
  echo IMPORTANT: Open .env and replace PUT_YOUR_MYSQL_ROOT_PASSWORD_HERE with your MySQL root password.
  echo Do not send your password to anyone.
  pause
  exit /b 1
)
if not exist "models\yolov8n-face.pt" (
  echo YOLO face model is missing.
  echo Run setup.bat again with internet access, or place models\yolov8n-face.pt manually.
  pause
  exit /b 1
)
call venv\Scripts\activate.bat
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
pause
