# AI Face Recognition Attendance System

This package keeps the existing HTML/CSS/Vanilla-JS application and the YOLO + SAHI + ArcFace + MySQL recognition pipeline, while fixing the issues found during live testing.

## What is fixed

- `.env` is loaded from the project root before MySQL/model configuration is read.
- YOLO model paths are resolved from the project root, so `models/yolov8n-face.pt` works even when Uvicorn is started from another directory.
- Temporal confirmation is keyed by the recognized student rather than only the detector track ID.
- Tracking tolerates normal YOLO/SAHI bounding-box jitter.
- Temporal confirmation defaults to 2 observations within 5 seconds.
- Frontend recognition polling is 500 ms, so the required observations fit comfortably inside the confirmation window.
- Nested YOLO/SAHI face detections are suppressed.
- MySQL attendance remains duplicate-safe with a unique `(session_id, student_db_id)` constraint.
- The database schema is created automatically by the backend.

## Folder

```text
AI_Attendance_Working/
├── backend/
│   └── main.py
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── models/
│   └── yolov8n-face.pt
├── database/
│   └── schema.sql
├── data/
├── recordings/saved/
├── .env
├── .env.example
├── requirements.txt
├── setup.bat
├── start.bat
└── README.md
```

## Requirements

Use **Python 3.11**, not Python 3.14. NumPy 1.26.4 and the TensorFlow/DeepFace stack are intended for this environment.

## First run

1. Install Python 3.11.
2. Make sure MySQL Server is running.
3. Run `setup.bat`.
4. Open `.env`.
5. Set:

```env
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=YOUR_REAL_MYSQL_PASSWORD
MYSQL_DATABASE=ai_attendance
```

6. Run `start.bat`.
7. Open `http://localhost:8000`.

The backend creates the MySQL database/tables automatically. MySQL Workbench can then be used to inspect `ai_attendance`, including `students`, `face_embeddings`, `attendance_sessions`, and `attendance`.

## Existing data

If your existing MySQL database already contains students and embeddings using the same schema, do not delete it. Point `.env` at that database. The application does not intentionally wipe existing rows.

If your old database uses a different schema, export/back up first and migrate deliberately rather than overwriting it.

## Attendance flow

```text
Webcam / video / RTSP
        ↓
YOLO face detection
        ↓
SAHI when difficult/small faces need sliced inference
        ↓
quality + alignment
        ↓
ArcFace 512-D embedding
        ↓
MySQL embedding gallery
        ↓
cosine distance + margin
        ↓
student-based temporal confirmation
        ↓
duplicate-safe MySQL attendance insert
        ↓
frontend Present state
```

## MySQL password error

If you see:

```text
Access denied for user 'root'@'localhost' (using password: NO)
```

your `.env` was not populated with the real password. Edit `MYSQL_PASSWORD`, stop Uvicorn, and restart it.

Never put your real database password in screenshots or send it in chat.
